use crate::{ChunkInfo, Endian, Error, Format, Limits, Pcm, reserve, timeline::Timeline};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Container {
    Riff,
    Rifx,
    Rf64,
    Bw64,
}
impl Container {
    pub const fn endian(self) -> Endian {
        match self {
            Self::Rifx => Endian::Big,
            _ => Endian::Little,
        }
    }
    pub const fn is_64(self) -> bool {
        matches!(self, Self::Rf64 | Self::Bw64)
    }
    pub(crate) fn fact_frames(self, count: u32, raw_ds64: Option<u64>) -> u64 {
        if self == Self::Rf64 && count == u32::MAX {
            raw_ds64.unwrap_or(u64::from(count))
        } else {
            u64::from(count)
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Ds64<'a> {
    pub riff_size: u64,
    pub data_size: u64,
    /// RF64 sampleCount, or the raw ignored dummy words for BW64.
    pub sample_count: u64,
    pub table: &'a [u8],
}
impl<'a> Ds64<'a> {
    pub fn parse(b: &'a [u8], limits: Limits) -> Result<Self, Error> {
        if b.len() < 28 {
            return Err(Error::Truncated);
        }
        let n = Endian::Little.u32(&b[24..]) as usize;
        if n > limits.size_table_entries {
            return Err(Error::Limit("ds64 size table"));
        }
        let len = n.checked_mul(12).ok_or(Error::Limit("ds64 size table"))?;
        Ok(Self {
            riff_size: Endian::Little.u64(b),
            data_size: Endian::Little.u64(&b[8..]),
            sample_count: Endian::Little.u64(&b[16..]),
            table: b
                .get(
                    28..28usize
                        .checked_add(len)
                        .ok_or(Error::Limit("ds64 size table"))?,
                )
                .ok_or(Error::Truncated)?,
        })
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Chunk<'a> {
    pub id: [u8; 4],
    /// Offset of the payload, relative to the start of this RIFF form.
    pub offset: u64,
    pub data: &'a [u8],
    /// Padding is excluded from data; retain it for exact container copying.
    pub padding: &'a [u8],
}

/// Checked chunk traversal. Only nonempty ds64 tables require allocation.
pub struct Chunks<'a> {
    bytes: &'a [u8],
    pos: usize,
    endian: Endian,
    ds64: Option<Ds64<'a>>,
    used: Vec<bool>,
    data_seen: bool,
    remaining: usize,
}
impl<'a> Chunks<'a> {
    pub(crate) fn new(
        bytes: &'a [u8],
        endian: Endian,
        ds64: Option<Ds64<'a>>,
        limits: Limits,
    ) -> Result<Self, Error> {
        let n = ds64.map_or(0, |d| d.table.len() / 12);
        let mut used = Vec::new();
        reserve(&mut used, n)?;
        used.resize(n, false);
        Ok(Self {
            bytes,
            pos: 12,
            endian,
            ds64,
            used,
            data_seen: false,
            remaining: limits.chunks,
        })
    }
    fn next_chunk(&mut self) -> Result<Chunk<'a>, Error> {
        if self.remaining == 0 {
            return Err(Error::Limit("chunk count"));
        }
        self.remaining -= 1;
        let h = self
            .bytes
            .get(self.pos..self.pos + 8)
            .ok_or(Error::Truncated)?;
        let id: [u8; 4] = h[..4].try_into().unwrap();
        let size = self.endian.u32(&h[4..]);
        let size = if let (u32::MAX, Some(d)) = (size, self.ds64) {
            if id == *b"data" && !self.data_seen {
                d.data_size
            } else {
                let i = d
                    .table
                    .as_chunks::<12>()
                    .0
                    .iter()
                    .enumerate()
                    .position(|(i, row)| row[..4] == id && !self.used[i])
                    .ok_or(Error::Invalid("missing ds64 table entry"))?;
                self.used[i] = true;
                Endian::Little.u64(&d.table[i * 12 + 4..])
            }
        } else {
            u64::from(size)
        };
        if id == *b"data" {
            self.data_seen = true;
        }
        let start = self.pos + 8;
        let end = u64::try_from(start)
            .unwrap()
            .checked_add(size)
            .ok_or(Error::Invalid("chunk size overflow"))?;
        let padded = end
            .checked_add(size & 1)
            .ok_or(Error::Invalid("chunk padding overflow"))?;
        if padded > self.bytes.len() as u64 {
            return Err(Error::Truncated);
        }
        self.pos = padded as usize;
        Ok(Chunk {
            id,
            offset: start as u64,
            data: &self.bytes[start..end as usize],
            padding: &self.bytes[end as usize..padded as usize],
        })
    }
}
impl<'a> Iterator for Chunks<'a> {
    type Item = Result<Chunk<'a>, Error>;
    fn next(&mut self) -> Option<Self::Item> {
        if self.pos == self.bytes.len() {
            return None;
        }
        let result = self.next_chunk();
        if result.is_err() {
            self.pos = self.bytes.len();
        }
        Some(result)
    }
}
impl std::iter::FusedIterator for Chunks<'_> {}

/// Validated borrowed WAVE form. Opening ordinary PCM/float files allocates nothing.
#[derive(Debug)]
pub struct Wave<'a> {
    pub container: Container,
    pub format: Format<'a>,
    pub ds64: Option<Ds64<'a>>,
    pub fact: Option<u64>,
    data: ChunkInfo,
    timeline: Option<Timeline>,
    bytes: &'a [u8],
    limits: Limits,
}
impl<'a> Wave<'a> {
    pub fn parse(b: &'a [u8]) -> Result<Self, Error> {
        Self::with_limits(b, Limits::default())
    }
    pub fn with_limits(b: &'a [u8], limits: Limits) -> Result<Self, Error> {
        if b.len() < 12 {
            return Err(Error::Truncated);
        }
        let container = match &b[..4] {
            b"RIFF" => Container::Riff,
            b"RIFX" => Container::Rifx,
            b"RF64" => Container::Rf64,
            b"BW64" => Container::Bw64,
            _ => return Err(Error::Invalid("RIFF signature")),
        };
        if &b[8..12] != b"WAVE" {
            return Err(Error::Invalid("not a WAVE form"));
        }
        let e = container.endian();
        let size32 = e.u32(&b[4..]);
        let ds64 = if container.is_64() {
            if b.get(12..16) != Some(b"ds64") {
                return Err(Error::Invalid("ds64 must be first"));
            }
            let h = b.get(16..20).ok_or(Error::Truncated)?;
            let n = e.u32(h) as u64;
            let end = 20u64.checked_add(n).ok_or(Error::Invalid("ds64 size"))?;
            if end > b.len() as u64 {
                return Err(Error::Truncated);
            }
            Some(Ds64::parse(&b[20..end as usize], limits)?)
        } else {
            None
        };
        let size = match ds64 {
            Some(d) if size32 == u32::MAX => d.riff_size,
            _ => u64::from(size32),
        };
        if size < 4 {
            return Err(Error::Invalid("RIFF size"));
        }
        let end = size
            .checked_add(8)
            .ok_or(Error::Invalid("RIFF size overflow"))?;
        if end > b.len() as u64 {
            return Err(Error::Truncated);
        }
        let bytes = &b[..end as usize];
        let mut format = None;
        let mut data = None;
        let mut fact = None;
        let mut timeline = None;
        let mut left = limits.chunks;
        for c in Chunks::new(bytes, e, ds64, limits)? {
            let c = c?;
            left = left.checked_sub(1).ok_or(Error::Limit("chunk count"))?;
            match &c.id {
                b"fmt " => {
                    if format.is_some() {
                        return Err(Error::Invalid("duplicate format chunk"));
                    }
                    if c.data.len() > limits.format_bytes {
                        return Err(Error::Limit("format size"));
                    }
                    format = Some(Format::parse(c.data, e)?);
                }
                b"data" => {
                    if data.is_some() {
                        return Err(Error::Unsupported("multiple data chunks"));
                    }
                    data = Some(c);
                }
                b"LIST" if c.data.starts_with(b"wavl") => {
                    if data.is_some() {
                        return Err(Error::Invalid("multiple WAVE data sections"));
                    }
                    let list = crate::metadata::List::parse(c.data, e, limits)?;
                    let mut index = Timeline::default();
                    let mut offset = c.offset + 4;
                    for child in list.entries() {
                        let child = child?;
                        left = left.checked_sub(1).ok_or(Error::Limit("chunk count"))?;
                        let silence = if child.id == *b"slnt" {
                            if child.data.len() != 4 {
                                return Err(Error::Invalid("slnt payload size"));
                            }
                            u64::from(e.u32(child.data))
                        } else {
                            0
                        };
                        index.push(
                            ChunkInfo {
                                id: child.id,
                                offset: offset + 8,
                                size: child.data.len() as u64,
                            },
                            silence,
                        )?;
                        offset += 8 + child.data.len() as u64 + child.padding.len() as u64;
                    }
                    timeline = Some(index);
                    data = Some(c);
                }
                b"fact" => {
                    if fact.is_some() {
                        return Err(Error::Invalid("duplicate fact chunk"));
                    }
                    if c.data.len() < 4 {
                        return Err(Error::Truncated);
                    }
                    let n = e.u32(c.data);
                    fact = Some(container.fact_frames(n, ds64.map(|d| d.sample_count)));
                }
                b"ds64" if !container.is_64() || c.offset != 20 => {
                    return Err(Error::Invalid("unexpected ds64"));
                }
                _ => {}
            }
        }
        let format = format.ok_or(Error::Invalid("missing format chunk"))?;
        let data = data.ok_or(Error::Invalid("missing data chunk"))?;
        if let Some(index) = &mut timeline {
            index.initialize(format, fact)?;
        } else if matches!(
            format.encoding,
            crate::Encoding::Pcm | crate::Encoding::Float
        ) && data.data.len() % usize::from(format.block_align) != 0
        {
            return Err(Error::Invalid("partial PCM frame"));
        }
        Ok(Self {
            container,
            format,
            ds64,
            fact,
            data: ChunkInfo {
                id: data.id,
                offset: data.offset,
                size: data.data.len() as u64,
            },
            timeline,
            bytes,
            limits,
        })
    }
    pub fn chunks(&self) -> Result<Chunks<'a>, Error> {
        Chunks::new(self.bytes, self.format.endian, self.ds64, self.limits)
    }
    /// A single contiguous data payload; wavl audio has no such byte slice.
    pub fn data(&self) -> Option<&'a [u8]> {
        self.timeline.is_none().then(|| self.audio_chunk().data)
    }
    pub fn data_offset(&self) -> Option<u64> {
        self.timeline.is_none().then_some(self.data.offset)
    }
    /// The physical data or LIST/wavl chunk, with exact original padding.
    pub fn audio_chunk(&self) -> Chunk<'a> {
        self.chunk(self.data)
    }
    pub fn wavl_chunks(&self) -> Option<impl Iterator<Item = Chunk<'a>> + '_> {
        self.timeline
            .as_ref()
            .map(|t| t.entries.iter().map(|e| self.chunk(e.chunk)))
    }
    fn chunk(&self, c: ChunkInfo) -> Chunk<'a> {
        let start = c.offset as usize;
        let end = start + c.size as usize;
        Chunk {
            id: c.id,
            offset: c.offset,
            data: &self.bytes[start..end],
            padding: &self.bytes[end..end + (c.size & 1) as usize],
        }
    }
    /// Original form including unknown chunks and their exact padding bytes.
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
    pub fn pcm(&self) -> Result<Pcm<'_>, Error> {
        match &self.timeline {
            Some(t) => Pcm::segmented(self.bytes, t, self.format),
            None => Pcm::new(self.data().unwrap(), self.format),
        }
    }
}
